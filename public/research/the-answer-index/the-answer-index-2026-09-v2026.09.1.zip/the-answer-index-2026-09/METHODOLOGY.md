# The Hendricks Answer Index: Methodology

Version 2.0. Panel version 2.0, sha 7a15060d8b5ec5f6. Taxonomy version 1.1.

## What this measures

The Answer Index measures which sources AI answer engines cite when people ask
ordinary buying and research questions, and how that composition differs by
industry and by engine.

It asks a fixed, published set of 480 questions across eight industries on
ChatGPT, Perplexity, Google AI Overviews and Gemini, records every source each
engine cites, classifies those sources, and reports the result as tracked series.

It measures the answer, not an advertiser. It does not score companies, rank
agencies, or grade any brand's visibility. That design choice is deliberate: an
index that ranks vendors becomes a sales instrument and stops being evidence.

## What this does not measure

State these before anyone else has to.

1. It does not measure traffic. A citation is not a click, and this study makes
   no claim about referral volume to any cited domain.
2. It does not measure what any individual user sees. Answer engines personalize
   and vary run to run. Every figure is a rate across repeated observations, not
   a description of one screen.
3. It does not establish causation. A source being cited often does not
   demonstrate why it was cited.
4. It is United States, English language only.

## The panel

480 questions. Eight verticals, sixty questions each:

| Vertical | Six subject areas |
|---|---|
| B2B SaaS and business software | CRM, help desk, observability, HR software, project management, endpoint security |
| Home services and trades | HVAC, plumbing, roofing, electrical, pest control, garage door |
| Professional services | accounting, business insurance, consulting, payroll and PEO, financial advisory, fractional CFO |
| Healthcare and dental | dental implants, orthodontics, dermatology, physical therapy, primary care, urgent care |
| Automotive sales and service | new cars, used cars, auto repair, tires, collision repair, maintenance plans |
| Consumer finance and insurance | personal loans, mortgage refinancing, auto insurance, homeowners insurance, credit card debt, life insurance |
| Retail and consumer products | mattresses, running shoes, laptops, air purifiers, skincare, espresso machines |
| Education and training | online MBA, coding bootcamps, nursing programs, PM certification, admissions consulting, online masters |

Within each vertical the sixty questions are split evenly across ten query
shapes, six questions per shape:

| Shape | What it represents |
|---|---|
| provider_discovery | Who should I hire, which vendors exist |
| comparison | A vs B, head to head |
| cost | What does it cost |
| selection_criteria | How do I choose, what do I look for |
| explainer | How does it actually work |
| problem_diagnosis | Symptom presented, cause requested |
| timing_trigger | When is it time to act |
| trust_credential | Is this provider legitimate, what credentials matter |
| category_definition | What is X |
| alternatives | Do I need this at all, what else could I do |

The shape distribution is identical in all eight verticals. This is the study's
central control. Because every vertical carries the same question mix, a
difference in source composition between two verticals is attributable to the
vertical rather than to the questions asked. Without that control, a finding like
"healthcare answers lean on reference sites more than SaaS answers do" is
unfalsifiable, because it could simply mean the healthcare questions happened to
be more definitional.

Three further panel rules:

- Questions are written in assistant voice, as a person would actually type them,
  with natural determiners and clause structure. A panel written in search
  keyword form measures what an engine does with a keyword and then gets reported
  as what an assistant does with a question. Those are different behaviors.
- No branded or navigational queries. A branded query returns the brand's own
  site and teaches nothing about the answer surface. Named vendors appear only
  inside comparison questions, where comparison is the user's actual intent.
- Local intent is carried in the prompt text, naming one of four fixed metros
  (Phoenix, Columbus OH, Sacramento, Kansas City), never inferred from the
  requesting IP address. Captures geolocate to the requesting IP and the uule
  parameter does not work on this stack, so a locally intended query run from one
  IP silently measures a single location. Naming the metro in the question makes
  the locality explicit and reproducible from any IP.

The four metros were selected to sit outside every Hendricks client market, so
that no client engagement, query set, or market appears anywhere in this corpus.

The full panel is published verbatim in `panel/panel.json`.

## Engines and models

Probed through the DataForSEO AI Optimization and SERP APIs.

| Engine | Model | Surface |
|---|---|---|
| ChatGPT | gpt-4.1, web_search enabled, US | ChatGPT Search citation panel |
| Perplexity | sonar, web_search enabled, US | Perplexity answer with sources |
| Gemini | gemini-2.5-flash, web_search enabled | Gemini grounded answer |
| Google AI Overviews | google organic advanced, load_async_ai_overview | AIO panel, reference cards plus inline links |

Two parser behaviors are load bearing and are documented because they have each
already produced a false finding in earlier work in this house:

- Gemini returns every citation as a vertexaisearch grounding redirect and puts
  the real source in the annotation title. Reading the URL alone collapses an
  entire run to one host, which reads as "Gemini shares no sources with any
  other engine." That is a parser artifact, not a finding.
- A Google AI Overview cites on two surfaces: the reference card list and the
  per element inline links. Reading references alone scores an inline only
  citation as absent.

## Definitions and denominators

| Term | Definition |
|---|---|
| cell | One (query, engine, run) probe |
| measured | The cell returned an answer. Failures are excluded from every denominator and reported separately as a failure rate |
| not_run | The cell was never attempted. Recorded distinctly from failure, because collapsing the two inflates the failure rate |
| cite_event | A cell in which a given domain appeared at least once. A domain cited three times inside one answer counts once |
| share | cite_events divided by measured cells, within the stated slice |

Counting a domain once per cell rather than once per link is deliberate. It makes
the metric answer the buyer's question, how often a source gets into the answer,
rather than rewarding engines and domains that simply produce more links.

Every table prints its denominator on the same line as the table heading, and
every row carries that denominator in the underlying JSON. The analyzer asserts
at runtime that no table mixes two denominators and that every printed share
recomputes from its own numerator and denominator. This check exists because a
prior analysis pass in this house published eleven rows computed against one
denominator while printing another. In a product whose entire pitch is
auditability, that class of error is fatal, so it is enforced by assertion rather
than by care.

Google AI Overview shares are computed against rendered panels, not against all
measured AIO cells, and the panel render rate is published beside them. An AI
Overview that never renders cannot cite anyone. Folding non renders into the
denominator reports a sourcing result when the actual finding was the absence of
the surface.

## Source classification

Domains are classified into eleven published classes by a rule set in
`taxonomy/source_classes.json`, applied in order: exact domain match, then suffix
rule, then unclassified.

Classes: community and forum, review platform, directory and lead generation,
reference and encyclopedic, government academic and standards, social and video,
trade body and professional association, publisher and trade media, national
brand or vendor site, independent operator site, and agency or content marketing
site.

The eleventh class, trade body and professional association, was added at
taxonomy version 1.1 after the first classification pass kept placing chambers of
commerce and professional societies into government and standards. A chamber of
commerce licenses nobody and sets no binding standard, and collapsing the two
inflates the apparent weight of official sources in exactly the industries where
that weight is the finding.

### The long tail is the dominant feature

The first capture round produced 3,246 distinct cited domains across 5,306
citation events, an average of 1.6 citations per domain. The answer surface is
not a short list of authoritative sites with a tail attached. It is
overwhelmingly tail. Any classification rule that covers only a top slice
therefore leaves most of the citation mass unnamed, and any report that hides
that behind a residual bucket is misreporting its own coverage.

Two rules follow:

1. Unclassified is never a headline. It is reported as its own labelled line with
   its exact share, never absorbed into another class and never used as a
   published series. Named class shares are therefore floors: classifying more of
   the tail can only move a named class up.
2. Coverage is stated as a number in every release. A release says what
   percentage of citation mass sits in a named class, rather than implying full
   coverage.

### How assignments are made, and how that is recorded

First pass is a local model, `qwen3.6:35b-a3b` running on hardware in-house, at
zero marginal cost. Every assignment it makes is written to
`taxonomy/reviewed_domains.json` carrying a `by` field naming the model and the
date, so a release can state exactly how much of its taxonomy was machine
labelled and a reviewer can pull the machine rows for checking. A human
assignment is never overwritten by a model.

The model is instructed to answer `unclassified` when unsure rather than guess,
because a disclosed tail is honest and a wrong class silently moves a published
number.

The first prompt version, carrying rules but no examples, produced a 15 to 20
percent error rate on a 31-domain sample: it placed security vendors into agency
content, a publisher into independent operators, and a chamber of commerce into
government. Adding the observed confusions to the prompt as worked examples, and
adding the missing association class, closed those specific failures. That
validation was performed on the same sample the examples were drawn from, which
is overfitting, so it establishes only that the named failure modes are fixed. A
blind spot-check on a random sample drawn from the current corpus is run before
any composition figure is published, and its measured error rate is reported
alongside the coverage number.

The independent operator class is assigned by recorded review rather than by seed
list, because that population is long tailed by nature and no list can enumerate
it.

## Known limitations

Stated here rather than discovered by a reader.

1. Google AI Overview presence from this data source has been observed wrong in
   both directions on a sibling account, producing both a false zero and a false
   positive. AIO figures are reported as directional and are confirmed against
   browser screenshot control runs before any AIO number is published as a
   headline.
2. ChatGPT returns at least one cited domain in only about half of its measured
   answers in comparable prior work. The ChatGPT citation denominator is
   therefore always published alongside its share figures.
3. Repeated runs of an identical query are a time series, not independent
   samples. Query diversity, not run count, carries the ranking claims. Run count
   carries only the volatility and trend claims.
4. One capture stack, one vendor. Every figure inherits whatever sampling
   behavior DataForSEO's own probing introduces. An independent second capture
   path is the highest priority methodological upgrade.
5. Eight verticals is eight verticals. Nothing here generalizes to industries
   not in the panel.

## Reproduction

```
python3 panel/build_panel.py                 # regenerate and verify the panel
python3 collector/run_panel.py --dry-run     # plan and cost, no calls
python3 collector/run_panel.py               # full run, all four engines
python3 collector/analyze.py --top 25        # tables, with self-check
```

Run files are immutable and keyed by run_id. No run ever overwrites another. Each
run records the panel version, the panel hash, the parser source hash, the engine
set requested, the location and language codes, and the actual dollar spend
reported by the API.

## Versioning

The panel is versioned and hashed. Any change to the panel increments the panel
version, and releases state which panel version produced them. A panel change
breaks comparability with earlier releases, and any release spanning a panel
change says so on its face.

## Cost

At list rates, one full run of all 480 queries across all four engines costs
about $55.20. Per query per engine: ChatGPT $0.070, Gemini $0.037, Perplexity
$0.006, Google AI Overviews $0.002.
