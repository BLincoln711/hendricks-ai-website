# Changelog

## v2026.09.1, 2026-09-01

First release. Panel v2.0, run run-2026-09-01T022903Z, 1,919 of 1,920 probes measured, 16,069 citation events across 7,775 distinct domains. Stability round run-2026-09-01T014944Z on the original 240 questions, Perplexity and Google AI Overviews only.
