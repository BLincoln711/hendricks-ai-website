# The Answer Index, September 2026

Open data for the Hendricks study of what AI answer engines cite.

Published by Hendricks, a Search Intelligence Engineering firm.
Author: Brandon Lincoln Hendricks.
Data captured 2026-09-01. Panel version 2.0, sha 7a15060d8b5ec5f6.

## What this is

We asked ChatGPT, Gemini, Perplexity and Google AI Overviews the same 480 questions
across eight industries and recorded every source each one cited. 1,920 probes,
1,919 measured, 16,069 citations across 7,775 distinct domains.

The full question panel is published here verbatim. That is deliberate. A study
whose instrument is private cannot be checked, and a finding that cannot be
checked is an assertion. Anyone can re-run this panel and compare.

## Files

| File | What it holds |
|---|---|
| `panel-v2.0.json` | The instrument. All 480 questions with industry and question-type labels. |
| `panel-v2.0.csv` | The same panel as a flat table. |
| `citations-by-domain.csv` | Every domain cited, per engine, with the count of answers citing it, the denominator, presence share, and share of that engine's total citations. |
| `engine-summary.csv` | Per engine: cells measured, citation rate, citations, distinct domains, mean sources per citing answer. |
| `industry-summary.csv` | Per industry: cells, citations, distinct domains, provider-owned share. |
| `question-type-summary.csv` | Citation rate by question type and engine. |
| `METHODOLOGY.md` | Definitions, denominators, engine configuration, and every known limitation. |

## Definitions you need before using these numbers

A citation is counted once per answer, never once per link. A domain cited three
times inside one answer counts once. This makes the metric answer how often a
source gets into the answer rather than rewarding engines that emit more links.

Presence is the share of an engine's answers containing a domain. Mass is that
domain's share of all citations the engine made. They are different measures and
they diverge sharply. Reddit is present in 68.1 percent of Perplexity answers and
holds 4.45 percent of its citations. Quoting either alone misleads.

Google AI Overview figures are computed against rendered panels only, 462 of 479
measured probes. An overview that never renders cannot cite anyone.

ChatGPT carried at least one citation in only 72 of its 480 answers, so any
ChatGPT share must state which denominator it uses.

## Known limitations

Read `METHODOLOGY.md` in full before citing. The short form:

This measures answer-engine APIs, not consumer apps. Source classification
carries a measured 28 percent disagreement rate by domain and 32 percent weighted
to citation mass, so the eleven-class breakdown is withheld and only the provider
split is published, as a floor. Gemini returns bare hostnames with no page path.
Stability was measured for two engines on half the panel across a 38 minute gap.
A citation is not a click and not a recommendation. Eight industries are eight
instances, not a sample of all industries.

## How to cite

Plain:

  Hendricks, Brandon Lincoln (2026). The Answer Index: what AI answer engines
  cite across eight industries. Hendricks. https://hendricks.ai/research/

Short, for press:

  Brandon Lincoln Hendricks, The Answer Index, Hendricks, September 2026
  (480 questions, four AI answer engines, 16,069 citations)

When quoting a figure, carry its denominator. Every number in this dataset has
one, and a figure reported without it cannot be checked.

## Corrections

Figures are versioned. Any correction is published at hendricks.ai/corrections
with a date and the superseded value, not edited silently.

## Licence

Free to use, quote and redistribute with attribution to Hendricks.
